package flappyBird;
/**
 * @author Megan K. Chinian (@kim_the_coder)
 * @version 1.0
 * Flappy Bird 2D game using a paint component for GUI
 * Renderer used for double Buffering
 */

//Imported Libraries
import java.awt.Graphics;

import javax.swing.JPanel;

public class Renderer extends JPanel //Inherits JPanel
{
	//default serial version UID
	private static final long serialVersionUID = 1L;
	
	/* (non-Javadoc)
	 * @see javax.swing.JComponent#paintComponent(java.awt.Graphics)
	 * paint component repaints the game board as the player(bird) moves through the board
	 */
	@Override
	protected void paintComponent(Graphics g) 
	{
		
		super.paintComponent(g);
		FlappyBird.flappyBird.repaint(g);
	}
}
